# SelfImprove — Desktop App

A dark, focused self-improvement tracker for sleep, workouts, eating, tasks, and goals.

## Quick Setup (5 minutes)

### Requirements
- [Node.js](https://nodejs.org) (v16 or later)

### Steps

1. **Extract** this folder somewhere permanent (e.g. `C:\Apps\selfimprove` or `~/Apps/selfimprove`)

2. **Open a terminal** in the folder and run:
   ```
   npm install
   npm start
   ```
   The app will open! Data is saved automatically to your system's app data folder.

3. **Build a proper installer** (optional, recommended):
   ```
   npm run build
   ```
   This creates an installer in the `dist/` folder.
   - **Windows**: Run the `.exe` installer → adds to Start Menu + can set to launch on startup
   - **Mac**: Drag the `.app` to Applications
   - **Linux**: Run the `.AppImage`

## Launch on PC Startup

### Windows (easiest)
After building and installing:
1. Press `Win + R`, type `shell:startup`, press Enter
2. Create a shortcut to `SelfImprove.exe` in that folder

### Mac
After installing to Applications:
1. System Preferences → General → Login Items
2. Add SelfImprove

### Without building (dev mode)
Create a `.bat` file (Windows) or shell script with:
```
cd C:\path\to\selfimprove
npm start
```
Add that to your startup folder.

## Features
- **Dashboard** — daily overview, mood tracker, quick notes
- **Sleep** — log bedtime/wake time, quality rating, weekly chart
- **Workouts** — log sessions by type, duration, intensity
- **Eating** — track meals, calories, water intake (8-glass tracker)
- **Tasks** — daily / weekly / monthly to-do lists with priorities
- **Goals** — daily / weekly / monthly goals with progress tracking
- **Streak counter** — tracks your daily usage streak

## Data
Your data is stored locally in JSON format at:
- **Windows**: `%APPDATA%\selfimprove\data.json`
- **Mac**: `~/Library/Application Support/selfimprove/data.json`
- **Linux**: `~/.config/selfimprove/data.json`
